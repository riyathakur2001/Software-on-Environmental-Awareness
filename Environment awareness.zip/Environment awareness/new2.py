import tkinter as tk
from tkinter import Toplevel, Label, messagebox
from PIL import Image, ImageTk


class ImageGalleryApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Environment Awareness")
        
        # Set the size of the main window
        self.root.geometry("1000x600")  # Increase window size to 1200x800

        # Add the heading
        heading = Label(root, text="Protecting Our Planet Starts Here!", font=("Helvetica", 28, "bold"), pady=20)
        heading.pack()

        # Set up a list of images and corresponding details
        self.programs = [
            {"image": "image1.png", "title": "Climate Change", "details": 
                "Climate change is the defining challenge of our time, driven by human actions like burning fossil fuels and deforestation. As global temperatures rise, we face increasingly severe weather events, rising sea levels, and devastating impacts on ecosystems. Addressing climate change requires collective action to reduce carbon emissions, transition to renewable energy, and adopt sustainable practices in every aspect of life."
            },
            {"image": "image2.png", "title": "Pollution", "details": 
                "Pollution poisons our air, water, and soil, threatening both our health and the planet’s biodiversity. From industrial emissions to plastic waste, human activity has created a toxic environment. Reducing pollution is essential for a cleaner, healthier future, and we can all contribute by cutting waste, embracing eco-friendly alternatives, and pushing for stronger environmental protections."
            },
            {"image": "image3.png", "title": "Deforestation", "details": 
                "Deforestation is a silent killer of biodiversity. Every tree cut down disrupts habitats, accelerates climate change, and diminishes our natural resources. Protecting our forests is crucial for maintaining the balance of the planet’s ecosystems. By supporting reforestation, sustainable forestry, and reducing our dependence on paper products, we can ensure a healthier world for future generations."
            },
            {"image": "image4.png", "title": "Water Conservation", "details": 
                "Water is life, yet it’s increasingly scarce. With growing populations and climate change, we are depleting freshwater sources faster than they can replenish. By using water more wisely—whether through reducing waste, fixing leaks, or supporting water-efficient technologies—we can ensure this vital resource is available for generations to come."
            },
            {"image": "image5.png", "title": "Waste Management and Recycling", "details": 
                "Our planet is drowning in waste, and the consequences are far-reaching. Proper waste management and recycling help conserve resources, reduce landfill overflow, and lower carbon emissions. By recycling, composting, and cutting down on single-use plastics, we can significantly reduce the environmental impact of our daily lives and move toward a circular economy."
            },
            {"image": "image6.png", "title": "Sustainable Agriculture", "details": 
                "The way we grow food has a profound impact on the environment. Unsustainable agricultural practices deplete soil, pollute water, and contribute to climate change. Supporting sustainable farming methods—like organic practices, crop rotation, and reducing food waste—not only protects the planet but also ensures healthy, nutritious food for all."
            },
            {"image": "image7.png", "title": "Biodiversity Conservation", "details": 
                "Biodiversity is the backbone of a healthy planet, providing the ecosystem services we depend on for survival. Yet, species extinction rates are skyrocketing due to habitat destruction, pollution, and climate change. By protecting wildlife, conserving habitats, and promoting sustainable practices, we can safeguard the delicate web of life that sustains us all."
            },
            {"image": "image8.png", "title": "Energy Efficiency", "details": 
                "Energy efficiency is one of the simplest yet most powerful tools in the fight against climate change. By using less energy to power our homes, businesses, and transportation, we reduce the strain on natural resources and lower carbon emissions. Small changes, like switching to LED bulbs, using energy-efficient appliances, or embracing renewable energy, can make a big difference in creating a more sustainable world."
            },
        ]

        self.display_images()

    def display_images(self):
        # Create a canvas with a scrollbar
        canvas = tk.Canvas(self.root)
        scrollbar = tk.Scrollbar(self.root, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        # Create a frame to hold the images inside the canvas
        image_frame = tk.Frame(canvas)

        # Scrollable region size
        canvas.create_window((0, 0), window=image_frame, anchor="nw")
        
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        # Load and display each image as a button
        for idx, program in enumerate(self.programs):
            try:
                image = Image.open(program["image"])
                image = image.resize((200, 200), Image.LANCZOS)  # Increase thumbnail size to 200x200
                photo = ImageTk.PhotoImage(image)

                # Calculate the row and column based on the index
                row = idx // 4  # Divide index by 4 to get the row
                col = idx % 4  # Modulo 4 gives the column (0-3)

                button = tk.Button(image_frame, image=photo, command=lambda idx=idx: self.show_details(idx))
                button.image = photo  # Keep a reference to prevent garbage collection
                button.grid(row=row, column=col, padx=20, pady=20)  # Arrange images in a grid

            except Exception as e:
                messagebox.showerror("Error", f"Unable to load image '{program['image']}': {e}")

        # Update the scrollable region size
        image_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))

    def show_details(self, idx):
        # Create a new window with more details about the selected program
        program = self.programs[idx]
        details_window = Toplevel(self.root)
        details_window.title(program["title"])

        Label(details_window, text=program["title"], font=("Arial", 18)).pack(pady=10)

        # Ensure text is displayed in a paragraph format
        details_label = Label(details_window, text=program["details"], font=("Arial", 14), wraplength=500, justify="left")
        details_label.pack(pady=10)

        # Load and display the program's image in the detail window
        try:
            image = Image.open(program["image"])
            image = image.resize((400, 400), Image.LANCZOS)  # Larger image size in detail view
            photo = ImageTk.PhotoImage(image)
            label = Label(details_window, image=photo)
            label.image = photo  # Keep a reference to prevent garbage collection
            label.pack(pady=10)
        except Exception as e:
            messagebox.showerror("Error", f"Unable to load image '{program['image']}': {e}")


if __name__ == "__main__":
    root = tk.Tk()
    app = ImageGalleryApp(root)
    root.mainloop()
